
import { useState } from "react";
import api from "../lib/api";
import { useRouter } from "next/router";
import Navbar from "../components/Navbar";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const router = useRouter();

  async function handleLogin(e) {
    e.preventDefault();
    try {
      const res = await api.post("/auth/login", { email, password });
      localStorage.setItem("token", res.data.token);
      localStorage.setItem("user", JSON.stringify(res.data.user));
      router.push("/dashboard");
    } catch (err) {
      alert(err.response?.data?.error || "Login failed");
    }
  }

  return (
    <>
      <Navbar />
      <div className="max-w-md mx-auto mt-10 p-4 border rounded">
        <h2 className="text-xl font-bold mb-4">Login</h2>
        <form onSubmit={handleLogin} className="space-y-3">
          <input type="email" placeholder="Email" value={email}
            onChange={e => setEmail(e.target.value)}
            className="border w-full p-2 rounded" />
          <input type="password" placeholder="Password" value={password}
            onChange={e => setPassword(e.target.value)}
            className="border w-full p-2 rounded" />
          <button className="bg-blue-600 text-white px-4 py-2 rounded w-full">Login</button>
        </form>
      </div>
    </>
  );
}
