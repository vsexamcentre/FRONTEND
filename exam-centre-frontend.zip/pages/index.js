
import { useEffect, useState } from "react";
import api from "../lib/api";
import Navbar from "../components/Navbar";

export default function Home() {
  const [tests, setTests] = useState([]);

  useEffect(() => {
    api.get("/tests")
      .then(res => setTests(res.data))
      .catch(console.error);
  }, []);

  return (
    <>
      <Navbar />
      <div className="max-w-3xl mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">📘 Daily Tests</h1>
        <ul>
          {tests.map(t => (
            <li key={t._id} className="border p-3 rounded mb-2 hover:bg-gray-50">
              <strong>{t.title}</strong> — {new Date(t.date).toDateString()}
            </li>
          ))}
        </ul>
      </div>
    </>
  );
}
