
import { useState } from "react";
import api from "../lib/api";
import Navbar from "../components/Navbar";

export default function UploadCSV() {
  const [file, setFile] = useState(null);
  const [msg, setMsg] = useState("");

  async function handleUpload(e) {
    e.preventDefault();
    const form = new FormData();
    form.append("file", file);
    try {
      const token = localStorage.getItem("token");
      const res = await api.post("/tests/upload-csv", form, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      setMsg(`✅ Uploaded ${res.data.createdCount} test(s)`);
    } catch (err) {
      setMsg("❌ Upload failed: " + (err.response?.data?.error || err.message));
    }
  }

  return (
    <>
      <Navbar />
      <div className="max-w-md mx-auto mt-10 border p-4 rounded">
        <h2 className="text-xl font-bold mb-4">Upload Test CSV</h2>
        <form onSubmit={handleUpload}>
          <input type="file" onChange={e => setFile(e.target.files[0])} className="mb-3" />
          <button className="bg-blue-600 text-white px-4 py-2 rounded">Upload</button>
        </form>
        {msg && <p className="mt-4">{msg}</p>}
      </div>
    </>
  );
}
