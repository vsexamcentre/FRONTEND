
import { useEffect, useState } from "react";
import api from "../lib/api";
import Navbar from "../components/Navbar";
import Link from "next/link";

export default function Dashboard() {
  const [user, setUser] = useState(null);
  const [tests, setTests] = useState([]);

  useEffect(() => {
    const userData = localStorage.getItem("user");
    if (userData) setUser(JSON.parse(userData));

    const token = localStorage.getItem("token");
    if (token) {
      api.get("/tests", { headers: { Authorization: `Bearer ${token}` } })
        .then(res => setTests(res.data))
        .catch(console.error);
    }
  }, []);

  if (!user) return <div className="p-4">Please login first.</div>;

  return (
    <>
      <Navbar />
      <div className="max-w-4xl mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">Welcome, {user.name}</h1>

        {user.role === "admin" ? (
          <>
            <Link href="/upload" className="bg-green-600 text-white px-3 py-2 rounded">
              + Upload CSV
            </Link>
            <h2 className="text-xl font-semibold mt-6 mb-2">All Tests</h2>
            {tests.map(t => (
              <div key={t._id} className="border p-2 mb-2 rounded">
                {t.title} — {new Date(t.date).toDateString()}
              </div>
            ))}
          </>
        ) : (
          <>
            <h2 className="text-xl font-semibold mb-2">Available Tests</h2>
            {tests.map(t => (
              <Link key={t._id} href={`/test/${t._id}`}>
                <div className="border p-2 mb-2 rounded hover:bg-gray-100">
                  {t.title} — {new Date(t.date).toDateString()}
                </div>
              </Link>
            ))}
          </>
        )}
      </div>
    </>
  );
}
