
import { useEffect, useState } from "react";
import { useRouter } from "next/router";
import api from "../../lib/api";
import Navbar from "../../components/Navbar";

export default function TestPage() {
  const router = useRouter();
  const { id } = router.query;
  const [test, setTest] = useState(null);

  useEffect(() => {
    if (!id) return;
    api.get(`/tests/${id}`)
      .then(res => setTest(res.data))
      .catch(console.error);
  }, [id]);

  if (!test) return <div className="p-4">Loading...</div>;

  return (
    <>
      <Navbar />
      <div className="max-w-3xl mx-auto p-4">
        <h1 className="text-2xl font-bold mb-4">{test.title}</h1>
        {test.questions.map((q, i) => (
          <div key={i} className="border p-3 mb-3 rounded">
            <p className="font-semibold">{i + 1}. {q.questionText}</p>
            <ul className="mt-2">
              {q.options.map((opt, j) => (
                <li key={j}>• {opt}</li>
              ))}
            </ul>
          </div>
        ))}
      </div>
    </>
  );
}
