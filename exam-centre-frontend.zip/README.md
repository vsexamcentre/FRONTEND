
# Exam Centre Frontend (Next.js + Tailwind)

## Features
- Connects to backend REST API
- Admin login & CSV upload
- Student dashboard & test list

## Quick start
1. Run `npm install`
2. Set backend URL in `lib/api.js`
3. Start local dev server:
   ```bash
   npm run dev
   ```
4. Open `http://localhost:3000`

## Deploy to Vercel
- Push to GitHub
- Import to [Vercel](https://vercel.com)
- It auto-detects Next.js and deploys free
