
import Link from "next/link";

export default function Navbar() {
  return (
    <nav className="bg-blue-600 text-white px-6 py-3 flex justify-between">
      <Link href="/" className="font-bold text-xl">Exam Centre</Link>
      <div>
        <Link href="/dashboard" className="mr-4 hover:underline">Dashboard</Link>
        <Link href="/login" className="hover:underline">Login</Link>
      </div>
    </nav>
  );
}
